<?php
/**
 * Functions
 *
 * @package media-ace
 * @subpackage Functions
 */

// Prevent direct script access.
if ( ! defined( 'ABSPATH' ) ) {
	die( 'No direct script access allowed' );
}

/**
 * Enqueue video playlist assets
 */
function mace_vp_enqueue_scripts() {
	$ver = mace_get_plugin_version();
	$plugin_url = mace_get_plugin_url();

	wp_enqueue_style( 'wp-mediaelement' );

	wp_enqueue_style( 'mace-vp-style', $plugin_url . 'includes/video-playlist/css/video-playlist.min.css' );

	wp_enqueue_script( 'mace-vp-renderer-vimeo', $plugin_url . 'includes/video-playlist/js/mejs-renderers/vimeo.min.js', array( 'wp-mediaelement' ), $ver, true );
	wp_enqueue_script( 'mace-vp', $plugin_url . 'includes/video-playlist/js/playlist.js', array( 'jquery', 'wp-mediaelement' ), $ver, true );
}

/**
 * Extract video url from content, divided by new line.
 *
 * @param string $content       Content.
 *
 * @return array
 */
function mace_vp_extract_urls( $content ) {
    // Strip PHP/HTML tags.
    $content = strip_tags( $content );

    // Decode HTML entities.
    $content = html_entity_decode( $content );

    // Remove whitespaces from the beginning and end of the text.
	$content = trim( $content );

	// Remove the shortcode opening tag.
	$content = str_replace( '[mace_video_item]', '', $content );

	// Use the closing tag as a delimiter.
	$list = explode( '[/mace_video_item]', $content );

	// Remove empty entries.
	$list = array_filter( $list );

	$urls = array();

	foreach ( $list as $item_shortcode ) {
		$urls[] = trim( $item_shortcode );
	}

	return $urls;
}
